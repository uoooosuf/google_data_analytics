# Our first calculations
quater_1_sales <- 35789.67
quater_2_sales <- 73643.05
midyear_sales <- quater_1_sales + quater_2_sales
endyear_sales <- midyear_sales * 2

