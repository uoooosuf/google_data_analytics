library("ggplot2")
library("palmerpenguins")

ggplot(data = penguins) + 
  geom_point(mapping = aes(x = flipper_length_mm, y = body_mass_g, shape = species,color = species  ))


#ggplot(data = penguins) + 
#  geom_point(mapping = aes(x = bill_length_mm, y = bill_depth_mm))

ggplot(data = penguins) + 
  geom_point(mapping = aes(x = flipper_length_mm, y = body_mass_g, alpha = species,color = species  ))

#change the overall appearance of a plot whithout regards to specific variable,
#write code outsite of the aes function.

ggplot(data = penguins) + 
  geom_point(mapping = aes(x = flipper_length_mm, y = body_mass_g, shape = species), color = "purple"   )

#doing more with ggplot 

ggplot(data = penguins) + 
  geom_smooth(mapping = aes(x = flipper_length_mm, y = body_mass_g), color = "purple") +
  geom_jitter(mapping = aes(x = flipper_length_mm, y = body_mass_g, shape = species) )

ggplot(data = penguins) + 
  geom_smooth(mapping = aes(x = flipper_length_mm, y = body_mass_g, linetype = species), color = "purple"   )



#Diamond dataset

ggplot(data = diamonds) +
  geom_bar(mapping = aes(x = cut, fill = clarity))
