install.packages('Tmisc')
library(Tmisc)
data("quartet")
View(quartet)

quartet %>%
  group_by(set) %>%
  summarise(mean(x),sd(x),mean(y),sd(y),cor(x,y))

# define set variable
set <- c("A", "B", "C", "D")

# ggplot(quartet, aes(x,y)) + geom_point() + geom_smooth(method = lm, se=FALSE) + facet_wrap(-set)

# use set variable in ggplot
ggplot(quartet, aes(x,y)) + geom_point() + geom_smooth(method = lm, se=FALSE) + facet_wrap(~ set)

install.packages('datasauRus')
library(datasauRus)

ggplot(datasaurus_dozen, aes(x=x,y=y,colour=dataset)) + geom_point() + theme_void() + theme (legend.position = 'none') + facet_wrap(~ dataset)
