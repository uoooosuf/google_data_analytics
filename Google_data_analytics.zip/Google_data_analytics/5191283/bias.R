
#working with bias data

install.packages("SimDesign")

actual_tem <- c(68.3, 70, 72.4, 71, 67, 70)
 predicted_tem <- c(67.9, 69, 71.5, 70, 67, 69)
 bias(actual_tem, predicted_tem)
 
 #sales
 
 actual_sales <- c(234, 036, 172, 101, 099)
 predicted_sales <- c(200, 150, 250, 300, 150)
 bias(actual_sales, predicted_sales)
 